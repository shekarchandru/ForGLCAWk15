package com.gl.springbootrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
