package com.greatlearning.library.service;

public interface LibraryCountService {

	long countLibraries();

	long countLibrariesWithZeroBooks();

}